#!/usr/bin/bash
echo 'In command 7'
