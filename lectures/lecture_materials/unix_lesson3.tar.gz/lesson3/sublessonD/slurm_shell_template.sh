#!/usr/bin/bash
#SBATCH --nodes=(fill in; usually is a 1)
#SBATCH --mem=(fill in number of megabytes of RAM)
#SBATCH --ntasks-per-node=(fill in; usually is 1)
#SBATCH -p (select your partition!)
#SBATCH -q (QOS! if using "msn" this is "msn"; otherwise it's "memlimit")
#SBATCH -o (output log file; optional, but handy to specify!)

# Type your awesome commands below!
