#!/usr/bin/bash
# Unix shell scripts accept arguments! They are stored in sequential order in the $1 $2 ... $n variables!

# First, let's make sure that the user entered something!
if [ $# -eq 0 ]
then
	# It's very good practice to make your own help message! Keep them nice and neat though!
	echo "Usage: $0 <file name>"
	echo "Please enter a file name!"
	# We didn't get a file name, so let's quit
	exit 1
fi

# OK, we have a file name! Let's check to see if it exists!
if [ -s $1 ]
then
	# It's there, so nothing to see here!
	echo 'The '$1' file exists! Joyous day!'
else
	# The unix read command takes user input from STDIN
	read -p "Would you like to create a new file: $1? (Y/N)" VAL
	# If the user entered a "y" or a "Y" then we're good to go! Make that file!
	if [ "$VAL" = "y" ] || [ "$VAL" = "Y" ]
	then
		echo "Here's your file"'!' > $1
		echo 'Created!'
	else
		# The user didn't want the file. That's a shame...
		echo 'Awww... :('
	fi
fi
