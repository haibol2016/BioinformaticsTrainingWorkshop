#!/usr/bin/bash
# This is your first Ceres script! I'm going to specify only one thing for you:
#SBATCH -t 1-0
# The above slurm setting gives your task 1 day to complete. It won't need that time!
# Unix scripts take the first argument and store it as $1

echo "I'm running! Hah!"

# this is the unix sleep command! It makes this program wait 15 minutes before executing
sleep 8m

for i in `grep '>' $1 | sed '/>//'`
do
	echo $i
done
