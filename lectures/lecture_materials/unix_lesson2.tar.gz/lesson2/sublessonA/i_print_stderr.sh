#!/usr/bin/bash
# The above is a shebang that says which program to use to interpret this file as a command!
# Any line that is prefaced by a '#' is a comment! The bash interpreter (in the shebang) doesn't care about these lines so you can say anything here.
# I could even say, "this cluster is so stupid, it thought that CPU was a misspelling of 'cup'!" See? No hurt feelings from the cluster!

echo "Using the echo command, and a redirect, I am printing this to STDERR!" > /dev/stderr
echo "STDERR is also text printed directly to the console, but it is different!" > /dev/stderr
echo "You can use STDERR to communicate to the user of your programs, without the message being incorporated into STDOUT!" > /dev/stderr

echo "I lied, and added a STDOUT printout. I'm pretty bad."
