#!/usr/bin/bash
# I ran out of stupid cluster jokes. Sorry!

cat
