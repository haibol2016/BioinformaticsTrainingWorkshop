#!/usr/bin/bash
# The above is a shebang that says which program to use to interpret this file as a command!
# Any line that is prefaced by a '#' is a comment! The bash interpreter (in the shebang) doesn't care about these lines so you can say anything here.
# I could even say, "this cluster is so stupid, it thought that its RAM was a male goat!" See? No hurt feelings from the cluster!

echo "Using the echo command, I am printing this to STDOUT!"
echo "STDOUT is text printed directly to the console!"
echo "You can use STDOUT to communicate to the user of your programs, or to read status reports from other scripts/programs!"
