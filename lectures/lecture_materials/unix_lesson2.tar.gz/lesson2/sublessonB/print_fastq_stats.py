#!/usr/bin/env python3
import collections
import pandas as pd
import numpy as np
import glob
import argparse


def parse_user_input():
    parser = argparse.ArgumentParser(
            description = "Print summary statistics on fastq files"
            )
    parser.add_argument('-f', '--file', 
                        help="A single fastq file. If specified at the same time as 'b', this is preferentially run.",
                        type=str, default=None
                        )
    parser.add_argument('-o', '--output',
                        help="Output file name",
                        type=str, required=True
                        )
    
    return parser.parse_args()

def main(args):
    # Get a list of fastq files in the directory
    files = []
    files.append(args.file)

    data = fastq_info()
    
    for filename in files:	
        data = get_fastq_info(filename, data)
    
    df = data.get_pddf()
    df.to_csv(args.output)
    print(df.describe())

            
def get_fastq_info(filename, fqinfo):

    for head, seq, qual in fastq_reader_fh(open(filename, 'r')):
        fqinfo.seq_lengths.append(len(seq))
        
        fqinfo.mean_qualities.append(round(np.mean(bytearray(qual, "ascii")) - 33, 2))
        
        fqinfo.kmers_start.append(seq[0:4])
        fqinfo.kmers_end.append(seq[-4:])

        ntc = collections.Counter()
        ntc.update(seq)
        fqinfo.nts_A.append(ntc['A'])
        fqinfo.nts_G.append(ntc['G'])
        fqinfo.nts_T.append(ntc['T'])
        fqinfo.nts_C.append(ntc['C'])
        fqinfo.nts_U.append(ntc['U'])

    return fqinfo

def fastq_reader_fh(infile):
  name = infile.readline().rstrip()
  while True:
    seq = ""
    for s in infile:
      if s[0] == '+':
        break
      else:
        seq += s.rstrip()
    qual = ""
    for q in infile:
      if len(qual) > 0 and  q[0] == '@':
        yield name, seq, qual
        name = q.rstrip()
        break
      else:
        qual += q.rstrip()
    else:
      yield name, seq, qual
      return
    
class fastq_info:

    def __init__(self):
        self.seq_lengths = []
        self.mean_qualities = []
        self.kmers_start = []
        self.kmers_end = []
        self.nts_A = []
        self.nts_G = []
        self.nts_T = []
        self.nts_C = []
        self.nts_U = []

    def get_pddf(self):
        df = pd.DataFrame({ "seq_length": self.seq_lengths,
                            "mean_quality": self.mean_qualities,
                            "kmers_start": self.kmers_start,
                            "kmers_end": self.kmers_end,
                            "nt_A": self.nts_A,
                            "nt_G": self.nts_G,
                            "nt_T": self.nts_T,
                            "nt_C": self.nts_C,
                            "nt_U": self.nts_U})
        return df.sort_values(by=['seq_length'])

        
if __name__ == "__main__":
    args = parse_user_input()
    main(args)
