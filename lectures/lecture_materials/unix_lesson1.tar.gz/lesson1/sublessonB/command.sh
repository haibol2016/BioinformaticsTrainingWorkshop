#!/usr/bin/bash
# The above is a "shebang" statement! It tells the operating system which program should be used to interpret this file!

# This is a "for" loop! Here we're looping through numbers 1 through 10 and storing them in a variable, i
for i in `seq 1 10`
do
	# Here we tell the console what we're doing
	echo "Doing important stuff! Iteration $i"
	# we're making a directory numbered after the value in $i
	mkdir test$i
	# Then we loop through another for loop with variable $j
	for j in `seq 1 10`
	do
		# For each j, we make a new directory and add in a blank test file
		mkdir test${i}/sub${j}
		touch test${i}/sub${j}/dummy.txt
	done
done

# This is a distraction to make everyone THINK we did nothing!
echo "Just kidding!"
